#include "BTreeNode.h"
#include <iostream>
#include <fstream>

using namespace std;

class BTree
{
  private:
    int t;
    int numberOfKeys;
    BTreeNode* root;
    BTreeNode* doSearch(BTreeNode*, string, int&, int);
    void doInsert(string, int);
    void splitChild(BTreeNode*, int);
    void insertNonFull(BTreeNode*, string, int);
    void print(BTreeNode*, int, ofstream&);
    void DISK_READ(BTreeNode*);
    void DISK_WRITE(BTreeNode*);
    void printOdemAlfabetica(BTreeNode*, int, ofstream&);

    
  public:
    BTree(int);
    ~BTree();

    void printOdemAlfabetica(int, string);
    bool search(string, int);
    bool insert(string, int);
    void print(int, string);
};
