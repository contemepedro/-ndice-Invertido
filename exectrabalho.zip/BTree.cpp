#include <string.h>
#include "BTree.h"
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

BTree::BTree(int order)
{
  t = order;
  numberOfKeys = 0;
  root = new BTreeNode(t);

  DISK_WRITE(root);
}

BTree::~BTree()
{
  delete root;
}

bool BTree::search(string palavra, int index)
{
  int i;
  if (doSearch(root, palavra, i, index) != 0)
  {
    return true;
  }
  return false;
}

BTreeNode* BTree::doSearch(BTreeNode* node, string palavra, int& i, int index)
{
  i = 0;
  while ((i<node->n) && (palavra > node->key[i]->palavras))
  {
    i++;
  }
  if (i < node->n && palavra == node->key[i]->palavras)
  {
    node->key[i]->contagem[index]+=1;
    return node;
  }
  else
  {
    if (node->leaf == true)
    {
      return 0;
    }
    DISK_READ(node->c[i]);
    return doSearch(node->c[i], palavra, i, index);
  }
}

void BTree::DISK_READ(BTreeNode* node)
{
  return;
}

void BTree::DISK_WRITE(BTreeNode* node)
{
  return;
}

bool BTree::insert(string key, int index)
{
  if (search(key, index) == true)
  {
    return false;  
  }
  doInsert(key, index);
  return true;
}

void BTree::doInsert(string palavra, int index)
{
  if (root->n == 5)
  {
    BTreeNode* s = new BTreeNode(t);

    s->leaf = false;
    s->n = 0;
    s->c[0] = root;
    root->parent = s;

    root = s;

    splitChild(s, 0);

    insertNonFull(s, palavra, index);
  }
  else
  {
    insertNonFull(root, palavra, index);
  }
}

void BTree::splitChild(BTreeNode* x, int i)
{
  BTreeNode* z = new BTreeNode(t);
  BTreeNode* y = x->c[i];

  z->leaf = y->leaf;
  z->n = t-1;

  for (int j=0; j<t-1; j++)
  {
    z->key[j] = y->key[j + t];
  }
  if (!y->leaf)
  {
    for (int j=0; j<t; j++)
    {
      z->c[j] = y->c[j + t];
    }
  }
  y->n = t-1;
  for (int j=x->n; j>i; j--)
  {
    x->c[j+1] = x->c[j];
  }
  x->c[i+1] = z;
  z->parent = x;
  for (int j=x->n-1; j>=i; j--)
  {
    x->key[j+1] = x->key[j];
  }
  x->key[i] = y->key[t-1];
  x->n++;

  DISK_WRITE(y);
  DISK_WRITE(z);
  DISK_WRITE(x);
}

void BTree::insertNonFull(BTreeNode* x, string palavra, int index)
{
  int i = x->n-1;

  if (x->leaf)
  {
    while (i >= 0 && palavra < x->key[i]->palavras)
    {
      x->key[i+1] = x->key[i];
      i--;
    }
    x->key[i+1] = new PalavraNode(palavra, 0);
    x->key[i+1]->contagem[index]+=1;
    x->n++;
    DISK_WRITE(x);
  }
  else
  {
    while (i >= 0 && palavra < x->key[i]->palavras)
    {
      i--;
    }
    i++;
    DISK_READ(x->c[i]);

    if (x->c[i]->n == 2*t-1)
    {
      splitChild(x, i);
      if (palavra > x->key[i]->palavras)
      {
        i++;
      }
    }
    insertNonFull(x->c[i], palavra, index);
  }
}

void BTree::printOdemAlfabetica(int index, string nomeArquivo)
{
  string arquivoSaida = nomeArquivo+".out";
  ofstream my_file(arquivoSaida);
  
  if (root != NULL)
  {
    printOdemAlfabetica(root, index, my_file);
  }
  my_file.close(); 
}

void BTree::printOdemAlfabetica(BTreeNode* node, int index,ofstream& my_file)
{
  string text = "";
	int i;
	for (i=0; i<node->n; i++)
	{
		if (node->leaf == false)
    {
      printOdemAlfabetica(node->c[i], index, my_file);
    }
		text += (node->key[i]->palavras + " ");
    for(int j=0; j<index; j++)
    {
      if(node->key[i]->contagem[j]!=0)
      {
        text += to_string(node->key[i]->contagem[j]) + " ";
        text += to_string(j+1) + " ";
      }
    }
      my_file << text;
      my_file << "\n";
      text = "";
	}

	if (node->leaf == false)
		printOdemAlfabetica(node->c[i], index, my_file);
}