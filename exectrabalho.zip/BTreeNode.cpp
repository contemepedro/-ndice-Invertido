#include "BTreeNode.h"
#include <iostream>
PalavraNode::PalavraNode(string p, int n)
{
  palavras = p;
  contagem = new int[n];
  contagem[n-1]++;
}

PalavraNode::~PalavraNode()
{
  palavras.clear();
  delete[] contagem;
}

BTreeNode::BTreeNode(int t)
{
  n = 0;
  leaf = true;
  key = new PalavraNode*[5];
  c = new BTreeNode*[6];    

  for(int i=0; i<6; i++)
  {
    c[i] = 0;
  }
  parent = 0;
}

BTreeNode::~BTreeNode()
{
  delete[] key;
  delete[] c;
}


