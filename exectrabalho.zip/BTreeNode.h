#include <string>
using namespace std;

class PalavraNode
{
  public:
    string palavras;
    int* contagem;

    PalavraNode(string, int);
    PalavraNode(int); 
    ~PalavraNode(); 
};

class BTreeNode
{
  public:
    int n; 
    bool leaf;
    PalavraNode** key;       
    BTreeNode** c;
    BTreeNode* parent;

    BTreeNode(int);
    ~BTreeNode();

};
