Integrantes:

Gabriel Thomaz e Silva
RGA: 2020.1905.006-1
TURMA: P02

Karoline de Souza Silva
RGA: 2016.1905.074-9
TURMA: P01

Pedro Henrique Conte de Araujo
RGA: 2020.1905.53-3
TURMA: P02