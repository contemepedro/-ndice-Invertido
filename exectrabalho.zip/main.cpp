#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
#include "BTree.h"
#include <ctype.h>
#include <algorithm>
using namespace std;

//funções auxiliares
void removerPontuacao(string&);
void transformarPalavraEmMinuscula(string&);

int main(int argc, char* argv[])
{
  string palavra;
  string nomeArquivoEntrada = argv[1]; 
  ifstream arquivo_de_entrada(nomeArquivoEntrada);
  int quantidade_de_arquivo;
  int indice_dos_arquivos = 0;

  BTree* tree = new BTree(3);

  if (arquivo_de_entrada.is_open())
  {
    arquivo_de_entrada >> palavra;
    quantidade_de_arquivo = stoi(palavra);
    while (arquivo_de_entrada >> palavra and indice_dos_arquivos<quantidade_de_arquivo)
    {
      ifstream arquivo(palavra);
      string textoDoArquivo;

      if(arquivo.is_open())
      {
        while(arquivo >> textoDoArquivo)
        {
          removerPontuacao(textoDoArquivo);
          transformarPalavraEmMinuscula(textoDoArquivo);
          tree->insert(textoDoArquivo, indice_dos_arquivos);
        }
      }
      arquivo.close();
      indice_dos_arquivos++;
    }
  }
  arquivo_de_entrada.close();

  tree->printOdemAlfabetica(quantidade_de_arquivo, nomeArquivoEntrada);
  delete tree;
  return 0;
}

void removerPontuacao(string& s)
{
  for (int i = 0, len = s.size(); i < len; i++)
  {
    if (ispunct(s[i]))
    {
      s.erase(i--, 1);
      len = s.size();
    }
  }
}

void transformarPalavraEmMinuscula(string &palavra)
{
  for_each(palavra.begin(), palavra.end(), [](char & c)
  {
    c = ::tolower(c);
  });
}